package MyProject;

// OverTheCounter class child of class Medicine 
public class OverTheCounter extends Medicine {

    // Create data field for Medicine class 
    private int minAge;

    /** Construct an OverTheCounter object with specified name, composition, 
   and minimun age by calling setMinAge method and super for the Medicine's
    data fields */
    public OverTheCounter(String name, String composition, int dose,
            int minAge) {
        this(name, composition, dose, 0, 10, minAge);
    }

    /** Construct an OverTheCounter object with specified name, composition, 
    dose, quantity, price and minimun age by calling setMinAge() method and 
    super for the Medicine's data fields */
    public OverTheCounter(String name, String composition, int dose,
            int quantity, double price, int minAge) {
        super(name, composition, dose, quantity, price);
        setMinAge(minAge);
    }

    /** Create setters and getters for encapsulation and Flexibility */
    // Return minimun age 
    public int getMinAge() {
        return minAge;
    }

    // Set a new minimum age 
    public void setMinAge(int minAge) {
        if (minAge > 0) {
            this.minAge = minAge;
        } else {
            this.minAge = 18;
        }
    }

    /** Override the toString method 
    return a String with the description of the Medicine and OverTheCounter */
    public String toString() {
        return "Over The Counter:\n" + super.toString()
                + "\n" + "minimum Age: " + minAge;
    }
}
