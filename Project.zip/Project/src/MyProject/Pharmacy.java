package MyProject;

// Create Pharmacy Class 
public class Pharmacy {

    // Create data fields for Pharmacy Class 
    private String name;
    // Create an array of medicines 
    public Medicine[] medicines;
    private int overTheCounterQuantity;
    private int prescriptionQuantity;
    private int numberOfMedicines;
    private static int MaxNumberOfMedicines;

    /** Construct a Pharmacy object with specified name and set other data 
        fields to their default values */
    public Pharmacy(String name) {
        this.medicines = new Medicine[100];
        setName(name);
        this.overTheCounterQuantity = 0;
        this.prescriptionQuantity = 0;
        this.numberOfMedicines = 0;
        setMaxNumberOfMedicines(100);
    }

    /** Create setters and getters for encapsulation and Flexibility */
    // Set a new name 
    public void setName(String name) {
        this.name = name;
    }

    // Set a new Maximum number of Medicines
    public static void setMaxNumberOfMedicines(int MaxNumberOfMedicines) {
        Pharmacy.MaxNumberOfMedicines = MaxNumberOfMedicines;
    }

    // Return an array of Medicines 
    public Medicine[] getMedicines() {
        return medicines;
    }

    // Return over the counter quantity 
    public int getOverTheCounterQuantity() {
        return overTheCounterQuantity;
    }

    // Return prescription quantity 
    public int getPrescriptionQuantity() {
        return prescriptionQuantity;
    }

    // Return number of Medicines 
    public int getNumberOfMedicines() {
        return numberOfMedicines;
    }

    // Return Maximum number of Medicines 
    public static int getMaxNumberOfMedicines() {
        return MaxNumberOfMedicines;
    }

    // Return name =
    public String getName() {
        return name;
    }

    public void addMedicine(Medicine medicine) {
        // Check if the array is already full
        if (numberOfMedicines == MaxNumberOfMedicines) {
            System.out.println(" The array is full,the medicine could not "
                    + "be added.");
        }
        // Check if the medicine already exists in the array
        for (int i = 0; i < numberOfMedicines; i++) {
            if (medicines[i].equals(medicine)) {
                System.out.println("Medicine already exists.");
            }
        }
        // If the medicine does not exist in the array, add it to the array
        medicines[numberOfMedicines++] = medicine;
        if (medicine instanceof OverTheCounter) {
            // Change the quantity of prescription and over the counter medicines
            overTheCounterQuantity += medicine.getQuantity();
        } else if (medicine instanceof Prescription) {
            prescriptionQuantity += medicine.getQuantity();
        }
    }

    public void raisePrices(double percentage) {
        // Loop through the array of medicines
        for (int i = 0; i < MaxNumberOfMedicines; i++) {
            // Get the current price of the medicine
            double price = medicines[i].getPrice();
            // Check if the percentage is positive or negative 
            if (percentage > 0) {
                price += price * percentage / 100;
            } else {
                price -= price * percentage / 100;
            }
            // Set the new price for the medicine
            medicines[i].setPrice(price);
        }
    }

    public int[] searchByName(String name) {
        // create an array to store the indices of the matching medicines
        int[] indices = new int[numberOfMedicines];
        // initialize a counter variable to keep track of the number of 
        // matches found
        int count = 0;
        // loop through all the medicines
        for (int i = 0; i < numberOfMedicines; i++) {
            // check if the name of the medicine matches the search name
            if (medicines[i].getName().equals(name)) {
                // if there is a match, store the index in the indices array
                indices[count++] = i;
            }
        }
        // return the array of matching indices
        return indices;

    }

    public int searchByNameAndDose(String name, int dose) {
        // Loop through all medicines in the array
        for (int i = 0; i < numberOfMedicines; i++) {
            // Check if the current medicine matches the given name and dose
            if (medicines[i].getName().equals(name)
                    && medicines[i].getDose() == dose) {
                // If there's a match, return the index of the medicine in 
                // the array
                return i;
            }
        }
        // If there's no match, return -1
        return -1;
    }

    public int[] searchByComposition(String composition) {
        // create an array to hold the indices of matching medicines
        int[] indices = new int[numberOfMedicines];
        int count = 0;
        // loop through all medicines in the array
        for (int i = 0; i < numberOfMedicines; i++) {
            // check if the composition of the medicine contains the given       
            if (medicines[i].getComposition().contains(composition)) {
                // add the index of the matching medicine to the indices array
                indices[count++] = i;
            }
        }
        // return the array of indices for matching medicines
        return indices;
    }

    public void sellMedicine(String name, double dose, int quantity) {
        // Loop through all medicines in the array
        for (int i = 0; i < numberOfMedicines; i++) {
            // Get the current medicine
            Medicine medicine = medicines[i];
            // Check if the medicine matches the given name and dose
            if (medicine.getName().equals(name)
                    && medicine.getDose() == dose) {
                // Check if there is enough quantity to sell
                if (medicine.getQuantity() >= quantity) {
                    // Reduce the quantity of the medicine
                    medicine.setQuantity(medicine.getQuantity() - quantity);
                    // Update the quantity counters based on the type of medicine
                    if (medicine instanceof OverTheCounter) {
                        overTheCounterQuantity -= quantity;
                    } else if (medicine instanceof Prescription) {
                        prescriptionQuantity -= quantity;
                    }
                    // Print a success message
                    System.out.println("Selling successful.");
                } else {
                    // Print an error message if the quantity is not enough
                    System.out.println("Available quantity is not enough.");
                }
            }
        }
        // Print an error message if the medicine was not found
        System.out.println("Medicine not found.");
    }

    public boolean restock(String name, int dose, int newquantity) {
        // Find the index of the medicine with the given name and dose
        int index = searchByNameAndDose(name, dose);
        // If the medicine is found
        if (index != -1) {
            // Increase the quantity of the medicine
            medicines[index].setQuantity(medicines[index].getQuantity()
                    + newquantity);
            // Return true to indicate that the restock was successful
            return true;
        }
        // Return false to indicate that the medicine was not found
        return false;
    }

    // Override the toString method 
    // Return a String with the description of the Pharmacy
    public String toString() {
        return "Pahrmacy: " + name + "\nNumber of Medicines: "
                + numberOfMedicines + "\nOver the counter quantity: "
                + overTheCounterQuantity + "\nPrescription quantity: "
                + prescriptionQuantity;
    }
}
