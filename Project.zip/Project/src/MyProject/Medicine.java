package MyProject;

public class Medicine {
   // Create data fields for Medicine class 

    private String name;
    private String composition;
    private int dose;
    private double price;
    private int quantity;

    /** Construct a Medicine object with specified name, composition and dose
    by calling it's setters */

    public Medicine(String name, String composition, int dose) {
         this(name,composition,dose,0,10);
 }
   /** Construct a Medicine object with specified name, composition , dose
   , quantity and price by calling it's setters */

    public Medicine(String name, String composition, int dose, int quantity,
            double price) {
        setName(name);
        setComposition(composition);
        setDose(dose);
        setQuantity(quantity);
        setPrice(price);
    }
    // Create setters and getters for encapsulation and Flexibility 
    // set a new name
    public void setName(String name) {
        this.name = name.toLowerCase();
    }
    // set a new composition
    public void setComposition(String composition) {
        this.composition = composition.toLowerCase();
    }
    // set a new dose
    public void setDose(int dose) {
        if (dose > 0) {
            this.dose = dose;
        } else {
            this.dose = 1000;
        }
    }
    // set a new price
    public void setPrice(double price) {
        if (price > 0) {
            this.price = price;
        } else {
            this.price = 10;
        }
    }
    // set a new quantity 
    public void setQuantity(int quantity) {
        if (quantity > 0) {
            this.quantity = quantity;
        } else {
            this.quantity = 0;
        }
    }
    // return name
    public String getName() {
        return name;
    }
    // return composition
    public String getComposition() {
        return composition;
    }
    // return dose
    public int getDose() {
        return dose;
    }
    // return price 
    public double getPrice() {
        return price;
    }

    public int getQuantity() {
        return quantity;
    }
    /** Override the toString method 
    return a String with the description of the Medicine */
    public String toString() {
        return "name: " + name + "\ncomposition: " + composition
                + "\ndose: " + dose + "mg" + "\nprice: " + price
                + "\nquantity: " + quantity;
    }
    /** Override the equals method to compare the Medicine object to another 
    object two objects are equal if they have same name and dose */

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof Medicine)) {
            return false;
        }
        // Explicit casting 
        Medicine medicine = (Medicine) object;
        if (this.name.equals(medicine.name)
                && this.dose == medicine.dose) {
            return true;
        }
        return false;
    }
}
