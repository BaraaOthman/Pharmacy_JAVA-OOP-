package MyProject;

/** Prescription class child of class Medicine */
public class Prescription extends Medicine {

    /** Create data field for prescription class */
    private String specialization;

    /** Construct a Prescription object with specified name, composition,  
    dose and specialization by calling setSpecializtion method and super for the 
    Medicine's data fields */
    public Prescription(String name, String composition, int dose,
            String specialization) {
        this(name, composition, dose, 0, 10, specialization);
    }

    /** Construct a Prescription object with specified name, composition, dose, 
    price and specialization */
    public Prescription(String name, String composition, int dose,
            int quantity, double price, String specialization) {
        super(name, composition, dose, quantity, price);
        setSpecialization(specialization);

    }

    /** Create setters and getters for encapsulation and Flexibility */
    /** Set a new specialization */
    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }

    /** Return Specialization */
    public String getSpecialization() {
        return specialization;
    }

    /** Override the toString method 
    return a String with the description of the Medicine and Prescription */
    public String toString() {
        return "\nPrescription:\n" + super.toString()
                + "\n" + "doctorSpecialization: " + specialization;
    }

}
