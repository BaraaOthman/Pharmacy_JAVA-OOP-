package MyProject;

import java.util.Arrays;
import java.util.Scanner;

public class Project {

    public static void main(String[] args) {
        Pharmacy p1 = new Pharmacy("mypharma");
        System.out.println("Welcome to \"" + p1.getName()
                + "\" pharmacy system.");
        System.out.println("_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _");
        /** Create a Scanner */
        Scanner input = new Scanner(System.in);
        System.out.println("Choose one the following options:");
        /** declare and initialize otherOption outside the loop */

        boolean otherOption = true;
        int choice;
        /** initialize an integer variable choice */
        do {
            choice = menu();
            /** call the menu() method and assign its return 
                                value to the variable choice */

            switch (choice) {
                /** cases for different choices */
                case 1:
                    /** if choice is equal to 1 */
                    System.out.println("Enter the information "
                            + "of the new medicine:");
                    System.out.print("Choose O or o for over the counter "
                            + "medicine and p or P for prescription "
                            + "medicine:");
                    /** read a character input from user and assign it to 
                        the variable character */
                    char character = input.next().charAt(0);
                    if (character == 'o' || character == 'O') {

                        System.out.print("Enter the minimum Age"
                                + " for this medicine: ");
                        int Age = input.nextInt();
                        /** create a new OverTheCounter object with given values
                             and assign it to the variable o1 */
                        OverTheCounter o1 = new OverTheCounter("tylenol",
                                "paracetamol", 1000,
                                30, 2.7, Age);
                        System.out.println(o1.toString());//print information of o1
                        /** add the o1 object to the
                                                    p1 object's medicine list */
                        p1.addMedicine(o1);
                        System.out.println("New medicine is added "
                                + "successfully");
                        System.out.println("__________________________ ");
                    } else {

                        System.out.print("Enter the doctor specialization "
                                + "for this medicine: ");
                        /** read a string input from user and assign it to 
                                                  the variable specialization */
                        String specialization = input.nextLine();
                        input.nextLine();
                        /** read and discard the newline 
                                               character */
                        /** create a new Prescription object with given values
                             and assign it to the variable ps1 */
                        Prescription ps1 = new Prescription("Xanax",
                                "alprazolan", 50,
                                50, 15.5, specialization);
                        // print information of ps1
                        System.out.println(ps1.toString());
                        /** add the ps1 object to the p1 object's medicine list 
                         */
                        p1.addMedicine(ps1);
                        System.out.println("New medicine is added "
                                + "successfully");
                        System.out.println("__________________________ ");
                    }
                    break; // end of case 1
                case 2:
                    System.out.print("Enter the name of the medicine "
                            + "to be found: ");
                    String name = input.nextLine();
                    /** read a string input from 
                                      user and assign it to the variable name */
                    p1.searchByName(name);
                    /** call the searchByName() method of 
                                            p1 object with the name parameter */
                    System.out.println("medicine found matching this "
                            + "name.");
                    /** create a new OverTheCounter object with given values
                             and assign it to the variable o1 */
                    OverTheCounter o1 = new OverTheCounter(name,
                            "paracetamol", 1000, 10);
                    System.out.println(o1.toString()); // print information of o1
                    System.out.println("_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _"
                            + " _ _ _ _ _ _ _ _ ");
                    break;// end of case 2 
                case 3:
                    // Prompt the user to enter the composition of the medicine
                    // to be found
                    System.out.print("Enter the composition of the medicine "
                            + "to be found: ");

                    // Read a line of input from the user and store it
                    // in the variable composition
                    String composition = input.nextLine();

                    // Search for medicines with the given composition and 
                    // store their indices in an array
                    int[] foundMedicines = p1.searchByComposition(composition);

                    // Check if any medicines were found with the given 
                    // composition
                    if (foundMedicines.length > 0) {

                        // Loop through the array of indices and print 
                        // information for each medicine found
                        for (int i = 0; i < foundMedicines.length; i++) {

                            // Get the index of the current medicine in the
                            // array of medicines
                            int index = foundMedicines[i];

                            // Get the medicine object at the current index
                            Medicine medicine = p1.medicines[index];

                            // Print information about the medicine
                            System.out.println(medicine.toString());
                            System.out.println("----");
                        }

                    } else {
                        // No medicines were found with the given composition
                        System.out.println("No medicines found with this "
                                + "composition.");
                    }
                    break; // end of case 3

                case 4:
                    System.out.print("Enter the name of the medicine: ");
                    String name1 = input.nextLine();
                    /** read a string input from 
                               user and assign it to the variable name1 */
                    input.nextLine();
                    /** read and discard the newline 
                                               character */
                    System.out.print("Enter the dose: ");
                    int dose = input.nextInt();
                    /** read an integer input from 
                               user and assign it to the variable dose */
                    System.out.print("Enter the quantity: ");
                    int quantity = input.nextInt();
                    /** read an integer input from 
                               user and assign it to the variable quantity */
                    p1.sellMedicine(name1, dose, quantity);
                    /** call sellMedicine() method to sell a medicine*/
                    System.out.println("_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ "
                            + "_ _ _ _ _ _ _ _ _ ");
                    break; // end of case 4
                case 5:
                    System.out.print("Enter the name of the medicine: ");
                    String name2 = input.nextLine();
                    /** read a string input from 
                               user and assign it to the variable name2 */
                    input.nextLine();
                    System.out.print("Enter the dose: ");
                    int dose1 = input.nextInt();
                    /** read an integer input from 
                               user and assign it to the variable dose1 */
                    System.out.print("Enter the qunatity: ");
                    int quantity1 = input.nextInt();
                    /** read an integer input from 
                               user and assign it to the variable quantity */
                    p1.restock(name2, dose1, quantity1);
                    /** call restock method in pharmacy class */
                    System.out.println("Restock Successful");
                    System.out.println("_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ "
                            + "_ _ _ _ _ _ _ _ _ ");
                    break; // end of case 5 
                case 6:
                    // Create an array of Medicines 
                    Medicine[] medicines = p1.getMedicines();
                    for (int i = 0; i < p1.getNumberOfMedicines(); i++) {
                        // display all information of each medicine 

                        System.out.println("Medicine " + (i + 1) + ": "
                                + medicines[i].toString());
                        System.out.println("----");
                    }
                    System.out.println("_ _ _ _ _ _ _ _ _ _ _ _ _ _ "
                            + "_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _");
                    break; // end of case 6
                case 7:
                    /** print pharmacy information */
                    System.out.println(p1.toString());
                    System.out.println("_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _"
                            + " _ _ _ _ _ _ _ _ ");
                    break; // end of case 7

                case 8:
                    /** set otherOption to false to exit the loop */
                    otherOption = false;
                    break; // end of case 8
                default:
                    System.out.println("Invalid choice. Please enter a"
                            + " valid choice.");
                    break;
            }
        } while (otherOption);
        /** continue running the loop while
                                        otherOption is true */
    }

    /** Create menu method that will display options for the user and return the 
        choice */
    public static int menu() {
        int choice;
        /** Create a Scanner */
        Scanner input = new Scanner(System.in);
        do {
            System.out.println("1- Add a new medicine");
            System.out.println("2- Search for a medicine by name");
            System.out.println("3- Search for a medicine by composition");
            System.out.println("4- Sell a medicine");
            System.out.println("5- Restock a medicine");
            System.out.println("6- Display all medicines");
            System.out.println("7- Display information");
            System.out.println("8- Exist");
            System.out.print("Enter your choice (between 1 and 8): ");
            choice = input.nextInt();
            if (choice < 1 || choice > 8) {
                System.out.print("Wrong choice please enter again: ");
                choice = input.nextInt();
            }
        } while (choice < 1 || choice > 8);
        /** continue running the loop while
                                        choice is invalid */

        return choice;
    }
}
